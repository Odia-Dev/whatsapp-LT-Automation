import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import db from '../db.js';
import { sendWhatsApp } from '../services/whatsapp.js';

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(process.cwd(), 'server', 'uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const safe = Date.now() + '-' + Math.random().toString(36).slice(2) + ext;
    cb(null, safe);
  }
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const ok = ['.png', '.jpg', '.jpeg', '.pdf'].includes(path.extname(file.originalname || '').toLowerCase());
    cb(ok ? null : new Error('Only png/jpg/pdf allowed'), ok);
  }
});

router.get('/', (req, res) => {
  const q = (req.query.q || '').toString().trim().toLowerCase();
  const status = (req.query.status || '').toString().trim().toLowerCase();
  let rows = db.prepare('SELECT * FROM bookings ORDER BY id DESC').all();
  if (q) rows = rows.filter(r => JSON.stringify(r).toLowerCase().includes(q));
  if (status) rows = rows.filter(r => (r.status || '').toLowerCase() === status);
  res.json(rows);
});

router.post('/', upload.single('proof'), async (req, res) => {
  try {
    const { customer, model, variant, amount, method, bank, executive, notes } = req.body;
    if (!customer || !model || !amount) return res.status(400).json({ error: 'customer, model, amount required' });
    const proof_path = req.file ? `/uploads/${req.file.filename}` : null;
    const info = db.prepare('INSERT INTO bookings (customer, model, variant, amount, method, bank, executive, notes, proof_path) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(customer, model, variant || null, Number(amount), method || null, bank || null, executive || null, notes || null, proof_path);
    const id = info.lastInsertRowid;
    db.prepare('INSERT INTO events (type, payload_json) VALUES (?,?)').run('booking_created', JSON.stringify({ id, customer, model, amount }));

    const accountant = process.env.ACCOUNTANT_NUMBER || '';
    if (accountant) {
      await sendWhatsApp({
        to: accountant,
        header: '🔔 New Booking Alert',
        model,
        customer,
        amount: `₹${Number(amount).toLocaleString('en-IN')}`,
        method: method || '—',
        executive: executive || '—',
        lines: [
          `👤 ${customer}`,
          `🚗 ${model}${variant ? ' ' + variant : ''}`,
          `💰 ₹${Number(amount).toLocaleString('en-IN')} ${method ? '(' + method + ')' : ''}${bank ? ' ' + bank : ''}`,
          `🧾 By: ${executive || '—'}`
        ],
        url: '' // TODO: link to hosted dashboard row if needed
      });
    }

    const row = db.prepare('SELECT * FROM bookings WHERE id=?').get(id);
    res.json(row);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

router.patch('/:id/verify', (req, res) => {
  const id = Number(req.params.id);
  const verified_by = (req.body?.verified_by || 'accountant').toString();
  db.prepare('UPDATE bookings SET status=?, verified_by=?, verified_at=datetime("now") WHERE id=?').run('verified', verified_by, id);
  const row = db.prepare('SELECT * FROM bookings WHERE id=?').get(id);
  res.json(row);
});

router.patch('/:id/flag', (req, res) => {
  const id = Number(req.params.id);
  db.prepare('UPDATE bookings SET status=? WHERE id=?').run('flagged', id);
  const row = db.prepare('SELECT * FROM bookings WHERE id=?').get(id);
  res.json(row);
});

export default router;
