import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { fileURLToPath } from 'url';
import cron from 'node-cron';
import db from './db.js';
import bookingsRoute from './routes/bookings.js';
import { sendWhatsApp } from './services/whatsapp.js';

const app = express();
const PORT = process.env.PORT || 8080;
const ORIGIN = process.env.FRONTEND_ORIGIN || `http://localhost:${PORT}`;
const TZ = process.env.TIMEZONE || 'Asia/Kolkata';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// security
app.use(helmet());
app.use(cors({ origin: ORIGIN, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const limiter = rateLimit({ windowMs: 60_000, max: 120 });
app.use(limiter);

// static assets (frontend)
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));
app.use('/', express.static(path.join(process.cwd(), 'web')));

// api routes
app.use('/api/bookings', bookingsRoute);

app.get('/api/stats', (req, res) => {
  const total = db.prepare('SELECT COUNT(*) as c FROM bookings').get().c;
  const verified = db.prepare("SELECT COUNT(*) as c FROM bookings WHERE status='verified'").get().c;
  const flagged = db.prepare("SELECT COUNT(*) as c FROM bookings WHERE status='flagged'").get().c;
  const pending = total - verified - flagged;
  res.json({ total, verified, flagged, pending });
});

// daily summary
if ((process.env.DAILY_SUMMARY_ENABLED || 'true').toLowerCase() === 'true') {
  const cronExp = process.env.DAILY_SUMMARY_CRON || '0 20 * * *';
  cron.schedule(cronExp, async () => {
    try {
      const totals = db.prepare('SELECT status, COUNT(*) c FROM bookings WHERE date(created_at)=date("now") GROUP BY status').all();
      const map = { pending: 0, verified: 0, flagged: 0 };
      for (const r of totals) map[r.status] = r.c;
      const sum = (map.pending||0)+(map.verified||0)+(map.flagged||0);
      const textLines = [
        '📊 Today\'s Booking Summary',
        `Total: ${sum}`,
        `✅ Verified: ${map.verified||0}`,
        `⌛ Pending: ${map.pending||0}`,
        `⚠️ Flagged: ${map.flagged||0}`
      ];
      const toList = (process.env.DAILY_SUMMARY_TO || '').split(',').map(s => s.trim()).filter(Boolean);
      for (const to of toList) {
        await sendWhatsApp({ to, header: 'Daily Summary', lines: textLines });
      }
      console.log('[CRON] Summary sent to', toList.join(', '));
    } catch (e) {
      console.error('[CRON] summary error', e.message);
    }
  }, { timezone: TZ });
}

app.listen(PORT, () => {
  console.log(`AutoEase MVP running on port ${PORT}`);
});
