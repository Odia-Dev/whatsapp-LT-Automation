import axios from 'axios';
import twilio from 'twilio';

const PROVIDER = process.env.PROVIDER || 'dryrun';
const TZ = process.env.TIMEZONE || 'Asia/Kolkata';

export async function sendWhatsApp(payload) {
  const to = payload.to;
  if (!to) throw new Error('Missing recipient');
  if (PROVIDER === 'dryrun') {
    console.log('[DRYRUN][WA]', JSON.stringify(payload, null, 2));
    return { ok: true, provider: 'dryrun' };
  }
  if (PROVIDER === 'wati') {
    const url = process.env.WATI_API_URL;
    const key = process.env.WATI_API_KEY;
    const template = process.env.WATI_TEMPLATE || 'booking_update';
    if (!url || !key) throw new Error('WATI creds missing');
    const body = {
      template_name: template,
      broadcast_name: 'Booking Transaction Alert',
      parameters: [
        payload.model || '',
        payload.customer || '',
        payload.amount || '',
        payload.method || '',
        payload.executive || '',
        new Date().toLocaleString('en-IN', { timeZone: TZ }),
        payload.url || ''
      ],
      receiver: to.replace(' ', '')
    };
    const res = await axios.post(url, body, { headers: { Authorization: key, 'Content-Type': 'application/json' } });
    return res.data;
  }
  if (PROVIDER === 'gupshup') {
    const url = process.env.GUPSHUP_API_URL;
    const apiKey = process.env.GUPSHUP_API_KEY;
    const app = process.env.GUPSHUP_APP;
    if (!url || !apiKey || !app) throw new Error('Gupshup creds missing');
    const text = [payload.header, ...payload.lines, payload.url ? `View: ${payload.url}` : ''].filter(Boolean).join('\n');
    const form = new URLSearchParams({
      'channel': 'whatsapp',
      'source': '',   // your approved number id
      'destination': to,
      'message': JSON.stringify({ type: 'text', text }),
      'src.name': app
    });
    const res = await axios.post(url, form, { headers: { apikey: apiKey, 'Content-Type': 'application/x-www-form-urlencoded' } });
    return res.data;
  }
  if (PROVIDER === 'twilio') {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_WHATSAPP_FROM;
    if (!sid || !token || !from) throw new Error('Twilio creds missing');
    const client = twilio(sid, token);
    const text = [payload.header, ...payload.lines, payload.url ? `View: ${payload.url}` : ''].filter(Boolean).join('\n');
    const res = await client.messages.create({
      from,
      to: `whatsapp:${to.replace('whatsapp:', '')}`,
      body: text
    });
    return res;
  }
  throw new Error('Unknown PROVIDER');
}
