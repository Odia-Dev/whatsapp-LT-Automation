const $ = (sel) => document.querySelector(sel);

function switchTab(tab) {
  const isForm = tab === 'form';
  $('#section-form').classList.toggle('hidden', !isForm);
  $('#section-dash').classList.toggle('hidden', isForm);
  $('#tab-form').classList.toggle('bg-black', isForm);
  $('#tab-form').classList.toggle('text-white', isForm);
  $('#tab-dash').classList.toggle('bg-black', !isForm);
  $('#tab-dash').classList.toggle('text-white', !isForm);
}

$('#tab-form').addEventListener('click', () => switchTab('form'));
$('#tab-dash').addEventListener('click', () => { switchTab('dash'); loadRows(); });

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function loadStats() {
  try {
    const s = await getJSON('/api/stats');
    $('#stat-total').textContent = s.total;
    $('#stat-verified').textContent = s.verified;
    $('#stat-pending').textContent = s.pending;
  } catch {}
}

async function loadRows(q='') {
  const data = await getJSON('/api/bookings' + (q ? ('?q=' + encodeURIComponent(q)) : ''));
  const tbody = $('#rows');
  tbody.innerHTML = '';
  for (const r of data) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="p-2">${r.id}</td>
      <td class="p-2">${r.customer}</td>
      <td class="p-2">${r.model} ${r.variant || ''}</td>
      <td class="p-2">₹${Number(r.amount).toLocaleString('en-IN')}</td>
      <td class="p-2">${r.status}</td>
      <td class="p-2">${r.proof_path ? `<a class='text-blue-600 underline' href='${r.proof_path}' target='_blank'>view</a>` : '-'}</td>
      <td class="p-2 space-x-2">
        <button data-id='${r.id}' class="verify px-2 py-1 bg-green-600 text-white rounded">Verify</button>
        <button data-id='${r.id}' class="flag px-2 py-1 bg-amber-600 text-white rounded">Flag</button>
      </td>
    `;
    tbody.appendChild(tr);
  }
  tbody.querySelectorAll('.verify').forEach(btn => btn.addEventListener('click', async (e) => {
    const id = e.target.getAttribute('data-id');
    await fetch('/api/bookings/' + id + '/verify', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ verified_by: 'accountant' }) });
    loadRows(); loadStats();
  }));
  tbody.querySelectorAll('.flag').forEach(btn => btn.addEventListener('click', async (e) => {
    const id = e.target.getAttribute('data-id');
    await fetch('/api/bookings/' + id + '/flag', { method: 'PATCH' });
    loadRows(); loadStats();
  }));
}

$('#search').addEventListener('input', (e) => loadRows(e.target.value));

$('#booking-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const fd = new FormData(form);
  $('#form-msg').textContent = 'Saving...';
  try {
    const res = await fetch('/api/bookings', { method: 'POST', body: fd });
    if (!res.ok) throw new Error(await res.text());
    form.reset();
    $('#form-msg').textContent = 'Saved & notified ✅';
    loadStats();
  } catch (err) {
    console.error(err);
    $('#form-msg').textContent = 'Error: ' + err.message;
  }
});

// initial
switchTab('form');
loadStats();
