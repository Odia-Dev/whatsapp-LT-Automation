# AutoEase – WhatsApp Group Chaos Killer (MVP)

Single‑server Node.js app that replaces WhatsApp groups with a **booking logger + WhatsApp auto‑notify + mini dashboard**.

### Quick start
1) Upload this folder to a new **Node.js** Replit (or run locally).
2) Add an `.env` (see `.env.example`).
3) Run:
```bash
npm install
npm start
```
4) Open the URL Replit shows (or http://localhost:8080).

### Features
- Booking form with file upload (png/jpg/pdf)
- Stores data in SQLite (`server/data/data.sqlite`)
- Sends accountant a WhatsApp alert (WATI/Gupshup/Twilio) or **DRYRUN** logs
- Dashboard to list, verify ✅ or flag ⚠️
- Daily summary at **20:00 Asia/Kolkata** using node-cron

### Env (.env)
See `.env.example` for all keys. Set `PROVIDER=dryrun` first.
